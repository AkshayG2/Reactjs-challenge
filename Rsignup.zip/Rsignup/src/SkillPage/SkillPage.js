import React from 'react';
import { Link } from 'react-router-dom';
import { connect } from 'react-redux';

import { userActions } from '../_actions';

class SkillPage extends React.Component {
	constructor(props) {
        super(props);

        this.state = {
			
            user: {
                firstName: '',
                lastName: '',
                
            },
            submitted: false,
			todos: [],
        };
	

        this.handleChange = this.handleChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
    }
  componentDidMount() {
    fetch('https://be.bhyve-app.com:3020/skills')
    .then(res => res.json())
    .then((data) => {
      this.setState({ todos: data })
      console.log(this.state.todos)
    })
    .catch(console.log)
  }
    handleChange(event) {
        const { name, value } = event.target;
        const { user } = this.state;
        this.setState({
            user: {
                ...user,
                [name]: value
            }
        });
    }

    handleSubmit(event) {
        event.preventDefault();

        this.setState({ submitted: true });
        const { user } = this.state;
        if (user.firstName && user.lastName ) {
            this.props.register(user);
        }
    }

    render() {
        const { registering  } = this.props;
        const { user, submitted, data } = this.state;
        return (
            <div className="col-md-9 col-md-offset-3">
                <h2>{this.username}Select Skills</h2>
                <form name="form" onSubmit={this.handleSubmit}>
					<div className="container">
						<div className="col-xs-12">
						
							{this.state.todos.map((todo) => (
								<div className="card">
									<div className="card-body">
									<h5 className="card-title">{todo.id} 
									<input type="checkbox"className="card-subtitle mb-2 text-muted"/>
									{todo.skillName}
								  </h5>
								</div>
							  </div>
							))}
							</div>
						   </div>
					
                    <div className="form-group">
					
                        <Link to="/Profile" className="btn btn-primary"> Submit </Link>
                        
						<div>
                        <Link to="/login">Logout</Link>
						</div>
                    </div>
                </form>
            </div>
        );
    }
}

	

function mapState(state) {
    const { users, authentication } = state;
    const { user } = authentication;
    return { user, users };
}

const actionCreators = {
    getUsers: userActions.getAll,
    deleteUser: userActions.delete
}

const connectedSkillPage = connect(mapState, actionCreators)(SkillPage);
export { connectedSkillPage as SkillPage };